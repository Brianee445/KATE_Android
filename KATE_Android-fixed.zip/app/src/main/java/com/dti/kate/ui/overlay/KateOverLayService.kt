package com.dti.kate.ui.overlay

import android.animation.ValueAnimator
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.Build
import android.os.CountDownTimer
import android.os.IBinder
import android.view.*
import android.widget.FrameLayout
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.dti.kate.R
import com.dti.kate.core.*
import com.dti.kate.utils.DeviceControlManager
import kotlinx.coroutines.*

/**
 * Floating bubble that listens, processes, and speaks entirely in place -
 * the app is never opened for this. Triggered by
 * KateForegroundService.onWakeGestureDetected() (shake/raise/wake word).
 * Hidden whenever idle (see showOverlayBubble/hideOverlayBubble) - it
 * appears on a wake trigger and disappears again once it's done speaking
 * or performing the requested action, rather than sitting on screen
 * permanently.
 *
 * Previously this class only rendered a draggable bubble with no wiring to
 * VoskManager, KateCommandProcessor, or TTS at all - it was instantiated
 * but never actually invoked from anywhere, so every gesture fell back to
 * KateActivity's onWakeGestureDetected() launching the full app. That
 * fallback is now reserved for the one case in
 * KateForegroundService.onWakeGestureDetected() that legitimately still
 * needs the app: fresh installs (Repository.isAuthenticated() == false),
 * where there's no onboarded session for the overlay to act on.
 */
class KateOverlayService : Service() {

    companion object {
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "kate_overlay_channel"
        private const val TAG = "KateOverlayService"

        private const val AUTO_COLLAPSE_DELAY_MS = 4000L

        private const val ACTION_ENSURE_SHOWING = "com.dti.kate.overlay.ENSURE_SHOWING"
        private const val ACTION_ACTIVATE = "com.dti.kate.overlay.ACTIVATE"

        /** Ensures the service and its (hidden) overlay view exist, without starting a listen cycle or making the bubble visible - call once (e.g. from KateForegroundService.onCreate) so the view is ready to show the instant the first wake trigger fires. */
        fun ensureShowing(context: Context) {
            val intent = Intent(context, KateOverlayService::class.java).apply {
                action = ACTION_ENSURE_SHOWING
            }
            startServiceCompat(context, intent)
        }

        /** Starts (if needed) and immediately kicks off a listen -> process -> speak cycle. This is the gesture/wake-word entry point. */
        fun activate(context: Context) {
            val intent = Intent(context, KateOverlayService::class.java).apply {
                action = ACTION_ACTIVATE
            }
            startServiceCompat(context, intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, KateOverlayService::class.java))
        }

        private fun startServiceCompat(context: Context, intent: Intent) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
            else context.startService(intent)
        }
    }

    private enum class OverlayState { IDLE, LISTENING, PROCESSING, SPEAKING }

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: View
    private lateinit var audioCapture: AudioCapture
    private lateinit var localSettings: LocalSettingsStore
    private lateinit var commandProcessor: KateCommandProcessor
    private lateinit var responseGenerator: KateResponseGenerator
    private lateinit var sttEngine: KateSttEngine

    private lateinit var ttsEngine: KateTtsEngine

    private var isExpanded = false
    private var overlayAdded = false
    private var state = OverlayState.IDLE
    private var avatarAnimator: ValueAnimator? = null
    private var collapseTimer: CountDownTimer? = null

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var activeCycle: Job? = null

    override fun onCreate() {
        super.onCreate()

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        localSettings = LocalSettingsStore(this)
        audioCapture = AudioCapture()

        // Repository requires an authenticated user for transcribeCloud's
        // token - null here just means "Kate Pro" quietly behaves like
        // "Kate Classic" (see KateSttEngine's class doc), not an error.
        val repo = com.dti.kate.repository.Repository(applicationContext)
        val repository = if (repo.isAuthenticated()) repo else null
        sttEngine = KateSttEngine(this, audioCapture, localSettings, repository)

        ttsEngine = KateTtsEngine(this)
        serviceScope.launch { ttsEngine.initialize() }

        responseGenerator = KateResponseGenerator()
        commandProcessor = KateCommandProcessor(
            context = this,
            responseGenerator = responseGenerator,
            deviceControl = DeviceControlManager(this),
            weatherService = WeatherService(),
            webSearchService = WebSearchService(),
            appLauncher = AppLauncher(this),
            musicLauncher = MusicLauncher(this),
            contactsHelper = ContactsHelper(this),
            locationHelper = LocationHelper(this),
            permissionBridge = object : KateCommandProcessor.PermissionBridge {
                override fun hasContacts() = ContextCompat.checkSelfPermission(
                    this@KateOverlayService, android.Manifest.permission.READ_CONTACTS
                ) == PackageManager.PERMISSION_GRANTED
                override fun hasLocation() = ContextCompat.checkSelfPermission(
                    this@KateOverlayService, android.Manifest.permission.ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
                // Neither a permission-dialog launcher nor accompanist's
                // rememberPermissionState exist outside an Activity -
                // opening the app is the one legitimate exception to
                // "never opens the app for this".
                override fun requestContacts() = openAppForPermission()
                override fun requestLocation() = openAppForPermission()
            },
        )

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, createNotification())
        setupOverlayView()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_ACTIVATE) startListenCycle()
        return START_STICKY
    }

    private fun openAppForPermission() {
        val launchIntent = Intent(this, com.dti.kate.ui.KateActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(launchIntent)
    }

    // ------------------------------------------------------------------
    // Listen -> process -> speak cycle
    // ------------------------------------------------------------------

    private fun startListenCycle() {
        if (activeCycle?.isActive == true) return // already mid-cycle, ignore re-trigger
        collapseTimer?.cancel()
        showOverlayBubble()
        playActivationPop()

        activeCycle = serviceScope.launch {
            setState(OverlayState.LISTENING)

            // Instant spoken ack the moment she's triggered, before STT even
            // starts - previously she went straight to silently listening
            // with only a color-pulse cue, which read as unresponsive/dead
            // rather than "ready". This is deliberately NOT awaited before
            // starting capture below: MicArbiter.setCapturing(true) still
            // happens immediately after, so the mic opens right away and
            // isn't blocked on TTS finishing - the ack plays concurrently
            // with the mic warming up.
            val tone = toneFromSlider(localSettings.getToneLevel())
            serviceScope.launch {
                ttsEngine.speakAndAwait(
                    responseGenerator.speechForListeningPrompt(tone, localSettings.getUserName()),
                    tone
                )
            }

            MicArbiter.setCapturing(true)

            val transcript = try {
                listenForTranscript()
            } finally {
                MicArbiter.setCapturing(false)
            }

            if (transcript.isNullOrBlank()) {
                setState(OverlayState.IDLE)
                // Nothing was heard, nothing to show - hide right away
                // rather than lingering visible with nothing to do.
                hideOverlayBubble()
                return@launch
            }

            setState(OverlayState.PROCESSING)
            val result = commandProcessor.process(transcript, tone)

            setState(OverlayState.SPEAKING)
            // Per product spec: the overlay only writes text on screen for
            // results worth reading back - a dictated message, a joke, a
            // calculation, or a search answer - never for ordinary device
            // actions ("turn on wifi", "call mom") where voice alone is
            // the whole interaction.
            val showsResult = when (result.action) {
                is KateAction.Calculate, is KateAction.WebSearch -> {
                    showResultText(result.speech); true
                }
                else -> false
            }
            speakAndAwait(result.speech, tone)

            setState(OverlayState.IDLE)
            if (showsResult) {
                // Give the user a moment to actually read the box before it
                // (and the bubble) disappear, rather than yanking it away
                // the instant speech ends.
                scheduleAutoHide()
            } else {
                hideOverlayBubble()
            }
        }
    }

    private suspend fun listenForTranscript(): String? = sttEngine.listen(serviceScope)

    private suspend fun speakAndAwait(text: String, tone: KateTone? = null) = ttsEngine.speakAndAwait(text, tone)

    // ------------------------------------------------------------------
    // Visual state - the logo itself pulses (no separate ring anymore,
    // no per-state color - see class doc for why: this is meant to read
    // as "just a logo that shows up", not a mic/status widget).
    // ------------------------------------------------------------------

    /**
     * One-shot "I heard you" acknowledgment - scale-in from 0 plus a
     * single 360° spin, played once at the very start of each cycle
     * (before any listening/processing begins). This is the entire
     * activation signal in the new design: no ring, no color, no mic
     * icon - just the logo appearing with a bit of motion so it doesn't
     * feel like it just snapped into existence.
     *
     * Same thread-safety reasoning as setState(): must run on the main
     * looper (Animator requirement), called from serviceScope
     * (Dispatchers.IO), so posted rather than run directly.
     */
    private fun playActivationPop() {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            try {
                val avatar = overlayView.findViewById<View>(R.id.kate_avatar)
                avatarAnimator?.cancel()
                avatar.scaleX = 0f
                avatar.scaleY = 0f
                avatar.rotation = 0f
                avatar.animate()
                    .scaleX(1f).scaleY(1f)
                    .rotationBy(360f)
                    .setDuration(500L)
                    .setInterpolator(android.view.animation.OvershootInterpolator(1.4f))
                    .start()
            } catch (e: Exception) {
                DebugLog.log(this@KateOverlayService, "KateOverlayService", "playActivationPop failed: ${e.javaClass.simpleName}: ${e.message}")
            }
        }
    }

    /**
     * Safe to call from any thread. startListenCycle runs on
     * serviceScope (Dispatchers.IO), and this touches views + starts a
     * ValueAnimator - both require the main/Looper thread. Confirmed via
     * crash report: calling this directly from the IO coroutine threw
     * "Animators may only be run on Looper threads" (ValueAnimator needs
     * a Looper) every time the overlay's listen cycle ran. Posting the
     * UI work to the main looper here means every call site stays as-is
     * - no need to wrap 6+ call sites in withContext(Dispatchers.Main)
     * individually, and any future call site is safe by default too.
     */
    private fun setState(newState: OverlayState) {
        state = newState
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            // Defensive: this runs async relative to when setState() was
            // called, so if the overlay window/view is torn down (service
            // stopping, view detached) in the gap between posting and
            // running, overlayView.findViewById or the animator can throw.
            // An uncaught exception here would crash the whole main thread
            // exactly like the original Looper bug did - a UI update
            // should never be able to take the whole process down.
            try {
                val avatar = overlayView.findViewById<View>(R.id.kate_avatar)

                avatarAnimator?.cancel()
                if (newState == OverlayState.IDLE) {
                    avatar.scaleX = 1f
                    avatar.scaleY = 1f
                } else {
                    // Gentle breathing pulse, no color/ring - speed is the
                    // only thing that varies by state now, same "legible
                    // at a glance" goal as the old ring pulse had.
                    val duration = if (newState == OverlayState.LISTENING) 700L else 1100L
                    avatarAnimator = ValueAnimator.ofFloat(1f, 1.08f).apply {
                        this.duration = duration
                        repeatMode = ValueAnimator.REVERSE
                        repeatCount = ValueAnimator.INFINITE
                        addUpdateListener {
                            val scale = it.animatedValue as Float
                            avatar.scaleX = scale
                            avatar.scaleY = scale
                        }
                        start()
                    }
                }
            } catch (e: Exception) {
                DebugLog.log(this@KateOverlayService, "KateOverLayService", "setState UI update failed (state=$newState): ${e.javaClass.simpleName}: ${e.message}")
            }
        }
    }

    /**
     * Safe to call from any thread, same reasoning as setState(): both
     * call sites (185, 204) run inside startListenCycle's serviceScope
     * coroutine (Dispatchers.IO). CountDownTimer's constructor creates a
     * Handler() internally, which requires a Looper on the constructing
     * thread - confirmed via bugreport: "Can't create handler inside
     * thread DefaultDispatcher-worker-1 that has not called
     * Looper.prepare()", 8 occurrences. This is a second, separate
     * Looper-requiring API from the ValueAnimator one in setState() - same
     * underlying mistake (IO-dispatcher coroutine touching an
     * Android UI/timer API), different call site, so it needed its own fix.
     */
    private fun scheduleAutoHide() {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            try {
                collapseTimer?.cancel()
                collapseTimer = object : CountDownTimer(AUTO_COLLAPSE_DELAY_MS, AUTO_COLLAPSE_DELAY_MS) {
                    override fun onTick(millisUntilFinished: Long) {}
                    override fun onFinish() {
                        if (isExpanded) toggleExpanded()
                        hideOverlayBubble()
                    }
                }.start()
            } catch (e: Exception) {
                DebugLog.log(this@KateOverlayService, "KateOverLayService", "scheduleAutoHide failed: ${e.javaClass.simpleName}: ${e.message}")
            }
        }
    }

    /** Makes the bubble visible again - called on any wake trigger. Safe to call even if it's already visible. */
    private fun showOverlayBubble() {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            try {
                collapseTimer?.cancel()
                if (::overlayView.isInitialized) overlayView.visibility = View.VISIBLE
            } catch (e: Exception) {
                DebugLog.log(this@KateOverlayService, "KateOverLayService", "showOverlayBubble failed: ${e.javaClass.simpleName}: ${e.message}")
            }
        }
    }

    /** Hides the bubble (and collapses any open result panel) - called immediately once a task with nothing to read finishes, or after scheduleAutoHide's grace period for one that showed a result. */
    private fun hideOverlayBubble() {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            try {
                if (isExpanded) toggleExpanded()
                avatarAnimator?.cancel()
                if (::overlayView.isInitialized) overlayView.visibility = View.GONE
            } catch (e: Exception) {
                DebugLog.log(this@KateOverlayService, "KateOverLayService", "hideOverlayBubble failed: ${e.javaClass.simpleName}: ${e.message}")
            }
        }
    }

    /**
     * Shows text in the expanded result box - used for TypeText's dictated
     * text and for TellJoke/Calculate/WebSearch's spoken answer, so the
     * user has something to read/re-read beyond just hearing it once. The
     * box itself is wrap_content (see overlay_kate.xml), so it already
     * sizes to short content like a one-line joke - this just adds a cap
     * for the opposite case (a long search answer), switching the
     * ScrollView from hugging its content to a fixed max height with
     * scrolling once text would push it past a comfortable size.
     */
    private fun showResultText(text: String) {
        val expandedView = overlayView.findViewById<FrameLayout>(R.id.overlay_expanded)
        val transcriptLabel = expandedView.findViewById<android.widget.TextView>(R.id.overlay_transcript)
        val scrollView = expandedView.findViewById<android.widget.ScrollView>(R.id.overlay_transcript_scroll)
        transcriptLabel?.text = text

        scrollView?.let { sv ->
            sv.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
            sv.requestLayout()
            sv.post {
                val maxHeightPx = dp(280)
                if (sv.height > maxHeightPx) {
                    sv.layoutParams.height = maxHeightPx
                    sv.requestLayout()
                }
            }
        }

        if (!isExpanded) toggleExpanded()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    // ------------------------------------------------------------------
    // Overlay shell setup - non-interactive, no drag/tap (see class doc)
    // ------------------------------------------------------------------

    private fun setupOverlayView() {
        if (overlayAdded) return
        overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_kate, null)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            },
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT,
        )
        // Bottom-anchored, not top-left - x/y below are offsets from the
        // bottom-left corner under Gravity.BOTTOM (no START/CENTER).
        // No touch listener anymore - the logo is purely a passive
        // acknowledgment, not an interactive control (see class doc).
        // Position is fixed, not draggable, since there's no drag
        // interaction to support anymore.
        params.gravity = Gravity.BOTTOM
        params.x = ((resources.displayMetrics.widthPixels - dp(88)) / 2).coerceAtLeast(0)
        params.y = dp(140)

        windowManager.addView(overlayView, params)
        overlayAdded = true

        overlayView.visibility = View.GONE // hidden until the first wake trigger - see showOverlayBubble
    }

    private fun toggleExpanded() {
        isExpanded = !isExpanded
        val expandedView = overlayView.findViewById<FrameLayout>(R.id.overlay_expanded)
        expandedView.visibility = if (isExpanded) View.VISIBLE else View.GONE
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Kate Assistant", NotificationManager.IMPORTANCE_LOW,
            ).apply {
                description = "Kate is running in the background"
                setShowBadge(false)
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun createNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Kate Assistant")
            .setContentText("Kate is listening for a wake gesture")
            .setSmallIcon(R.drawable.ic_kate_notification)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        activeCycle?.cancel()
        serviceScope.cancel()
        avatarAnimator?.cancel()
        collapseTimer?.cancel()
        audioCapture.stop()
        MicArbiter.setCapturing(false)
        ttsEngine.close()
        if (overlayAdded && ::overlayView.isInitialized) {
            windowManager.removeView(overlayView)
        }
    }
}
