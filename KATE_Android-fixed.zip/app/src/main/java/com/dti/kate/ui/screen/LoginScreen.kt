package com.dti.kate.ui.screen

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.dti.kate.R
import com.dti.kate.service.KateForegroundService
import com.dti.kate.ui.components.*
import com.dti.kate.ui.theme.*

@Composable
fun LoginScreen(
    navController: NavController,
    viewModel: AuthViewModel = AuthViewModel(LocalContext.current),
) {
    val context = LocalContext.current

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var passwordVisible by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Background)
            .verticalScroll(scrollState)
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        com.dti.kate.ui.components.KateAvatar(
            size = 80.dp,
            modifier = Modifier.padding(bottom = 16.dp),
        )

        Text(
            text = "Welcome Back",
            style = MaterialTheme.typography.headlineLarge.copy(
                fontFamily = JetBrainsMono,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
            ),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(bottom = 8.dp),
        )

        Text(
            text = "Sign in to continue using Kate",
            style = MaterialTheme.typography.bodyMedium.copy(
                color = TextSecondary,
            ),
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(bottom = 32.dp),
        )

        KateTextField(
            value = email,
            onValueChange = { email = it; errorMessage = null },
            label = "Email Address",
            placeholder = "you@example.com",
            modifier = Modifier.fillMaxWidth(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            isError = errorMessage != null,
            errorMessage = errorMessage,
        )

        Spacer(modifier = Modifier.height(16.dp))

        KateTextField(
            value = password,
            onValueChange = { password = it; errorMessage = null },
            label = "Password",
            placeholder = "Enter your password",
            modifier = Modifier.fillMaxWidth(),
            isPassword = !passwordVisible,
            trailingIcon = {
                IconButton(onClick = { passwordVisible = !passwordVisible }) {
                    Icon(
                        imageVector = if (passwordVisible) Icons.Outlined.Visibility else Icons.Outlined.VisibilityOff,
                        contentDescription = if (passwordVisible) "Hide password" else "Show password",
                        tint = TextSecondary,
                    )
                }
            },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            isError = errorMessage != null,
            errorMessage = errorMessage,
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End,
        ) {
            KateTextButton(
                text = "Forgot Password?",
                onClick = { navController.navigate("forgot_password") },
                color = Purple30,
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        KateGradientButton(
            text = "Sign In",
            onClick = {
                if (validateInput(email, password)) {
                    isLoading = true
                    viewModel.login(email, password) { success, error ->
                        isLoading = false
                        if (success) {
                            // Start Kate's background service (charging-state
                            // speech, future always-on listening) right away
                            // rather than waiting for the next app launch.
                            //
                            // Only do this if RECORD_AUDIO is already granted —
                            // starting a microphone-type foreground service
                            // without it throws a SecurityException on API 34+.
                            // If it's not granted yet, HomeScreen's existing
                            // permission flow will request it and can start
                            // the service itself once the user grants it.
                            val hasMicPermission = ContextCompat.checkSelfPermission(
                                context, Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED

                            if (hasMicPermission) {
                                val serviceIntent = Intent(context, KateForegroundService::class.java)
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                                    context.startForegroundService(serviceIntent)
                                } else {
                                    context.startService(serviceIntent)
                                }
                            }

                            val destination = if (com.dti.kate.core.LocalSettingsStore(context).hasAgreedToTerms()) "home" else "user_agreement"
                            navController.navigate(destination) {
                                popUpTo("login") { inclusive = true }
                            }
                        } else {
                            errorMessage = error ?: "Invalid email or password"
                        }
                    }
                } else {
                    errorMessage = "Please enter a valid email and a password of at least 6 characters"
                }
            },
            modifier = Modifier.fillMaxWidth(),
            isLoading = isLoading,
            isEnabled = !isLoading,
            size = KateButtonSize.Large,
        )

        if (isLoading) {
            Text(
                text = "Connecting to Kate's servers...",
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary,
                modifier = Modifier.padding(top = 8.dp),
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.padding(top = 16.dp),
            horizontalArrangement = Arrangement.Center,
        ) {
            Text(
                text = "Don't have an account? ",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
            )
            KateTextButton(
                text = "Sign Up",
                onClick = { navController.navigate("register") },
                color = Purple70,
            )
        }
    }
}

private fun validateInput(email: String, password: String): Boolean {
    return email.isNotEmpty() && android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches() &&
            password.isNotEmpty() && password.length >= 6
}
